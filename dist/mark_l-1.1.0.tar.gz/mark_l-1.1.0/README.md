# Personal AI

Personal AI is a desktop assistant that combines voice interaction, local memory, browser automation, desktop control, file tools, and a web dashboard.

## Features

- Voice-first assistant experience with Gemini-backed conversational AI
- Local memory and personalization settings stored in the project config directory
- Browser, desktop, file, system, and app-control actions
- Optional dashboard for monitoring and management
- Windows-first packaging with PyInstaller support

## Requirements

- Python 3.11+
- A Gemini API key configured either via environment variable or `config/api_keys.json`

## Quick start

1. Create and activate a virtual environment.
2. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
3. Configure your API key:
   - Set `GEMINI_API_KEY`, or
   - create `config/api_keys.json` using the example file.
4. Launch the app:
   ```bash
   python main.py
   ```

## Optional extras

```bash
python -m pip install -e .[dashboard,windows,browser]
```

## Publishing build

```bash
python -m pip install build
python -m build
```

## License

This project is licensed under CC BY-NC 4.0.
